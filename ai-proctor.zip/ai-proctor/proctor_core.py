"""
proctor_core.py - detection + overlay + violation scoring.

Analyzer      : frame -> raw info (faces, head ratios, boxes, phone/book/person)
Session       : raw info -> violations (hold time + cooldown + score)
build_overlay : boxes + live warning text jo screen par draw hote hain
"""
import json
import threading
import time
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np

# ------------------------- CONFIG (yahan tune karo) -------------------------
CALIB_FRAMES = 10          # shuru ke itne frames me seedha dekho (baseline)
YAW_THRESHOLD = 0.12       # baseline se itna side ghoome to "looking away"
PITCH_DOWN = 0.09          # neeche dekhna (notes / phone)
PITCH_UP = 0.11            # upar dekhna
YOLO_CONF = 0.40
COOLDOWN = 8               # ek hi violation dobara log hone se pehle (sec)
FLAG_SCORE = 10            # is score par session "flagged for human review"

# code: (hold seconds before LOGGING, weight, message)
# NOTE: screen par warning/box turant dikhta hai, hold sirf log/score ke liye hai.
RULES = {
    "NO_FACE":         (3.0, 2, "Face camera me nahi dikh raha"),
    "MULTIPLE_FACES":  (1.5, 4, "Ek se zyada log frame me detect hue"),
    "LOOKING_AWAY":    (2.0, 1, "Screen se side me dekh raha hai"),
    "LOOKING_DOWN":    (2.5, 1, "Lambe time se neeche dekh raha hai"),
    "PHONE":           (1.0, 5, "Mobile phone detect hua"),
    "BOOK":            (2.0, 3, "Book / notes detect hue"),
    # browser-side events (turant log)
    "TAB_SWITCH":      (0, 2, "Tab / window switch kiya"),
    "COPY_PASTE":      (0, 2, "Copy / paste / cut try kiya"),
    "FULLSCREEN_EXIT": (0, 2, "Fullscreen se bahar nikla"),
    "NOISE":           (0, 1, "Background me lagataar awaaz / baat-cheet"),
}

LIVE_TEXT = {
    "NO_FACE": "NO FACE DETECTED",
    "MULTIPLE_FACES": "EXTRA PERSON DETECTED",
    "LOOKING_AWAY": "LOOKING AWAY FROM SCREEN",
    "LOOKING_DOWN": "LOOKING DOWN",
    "PHONE": "PHONE DETECTED",
    "BOOK": "BOOK / NOTES DETECTED",
}

LOG_DIR = Path(__file__).parent / "logs"
YOLO_NAMES = {0: "person", 67: "phone", 73: "book"}   # COCO ids


# ------------------------------- ANALYZER -----------------------------------
class Analyzer:
    def __init__(self, use_yolo=True, static=False, yolo_weights="yolov8n.pt"):
        import mediapipe as mp

        self._lock = threading.Lock()
        self.mesh = mp.solutions.face_mesh.FaceMesh(
            static_image_mode=static,   # server (multi-session) me True
            max_num_faces=3,
            refine_landmarks=False,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5,
        )
        self.yolo = None
        if use_yolo:
            from ultralytics import YOLO
            self.yolo = YOLO(yolo_weights)  # pehli baar auto-download

    @staticmethod
    def _head_ratios(lm):
        # 1 nose tip, 234/454 cheeks, 10 forehead, 152 chin
        nose, left, right, top, chin = lm[1], lm[234], lm[454], lm[10], lm[152]
        yaw = (nose.x - left.x) / ((right.x - left.x) or 1e-6)      # ~0.5 = seedha
        pitch = (nose.y - top.y) / ((chin.y - top.y) or 1e-6)       # ~0.55-0.6 = seedha
        return yaw, pitch

    def analyze(self, frame_bgr):
        info = {"faces": 0, "yaw": 0.5, "pitch": 0.58, "phone": 0, "book": 0,
                "persons": 0, "face_boxes": [], "objects": []}
        with self._lock:
            res = self.mesh.process(cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB))
            faces = res.multi_face_landmarks or []
            info["faces"] = len(faces)
            for f in faces:
                xs = [p.x for p in f.landmark]
                ys = [p.y for p in f.landmark]
                info["face_boxes"].append([max(0.0, min(xs)), max(0.0, min(ys)),
                                           min(1.0, max(xs)), min(1.0, max(ys))])
            if faces:
                info["yaw"], info["pitch"] = self._head_ratios(faces[0].landmark)

            if self.yolo is not None:
                out = self.yolo.predict(frame_bgr, conf=YOLO_CONF, classes=[0, 67, 73],
                                        verbose=False, imgsz=480)[0]
                boxes = out.boxes.xyxyn.tolist()
                clss = out.boxes.cls.tolist()
                confs = out.boxes.conf.tolist()
                for b, c, p in zip(boxes, clss, confs):
                    name = YOLO_NAMES.get(int(c))
                    if not name:
                        continue
                    info["objects"].append({"name": name, "box": b, "conf": float(p)})
                    if name == "phone":
                        info["phone"] += 1
                    elif name == "book":
                        info["book"] += 1
                    else:
                        info["persons"] += 1
        return info


# -------------------------------- SESSION -----------------------------------
class Session:
    def __init__(self, sid, name=""):
        self.sid = sid
        self.name = name
        self.started = time.time()
        self.violations = []
        self.score = 0
        self._since = {}        # code -> kab se active
        self._last_fired = {}   # code -> last log time
        self._calib = []
        self.base_yaw, self.base_pitch = 0.5, 0.58

    @property
    def calibrating(self):
        return len(self._calib) < CALIB_FRAMES

    @property
    def flagged(self):
        return self.score >= FLAG_SCORE

    def evaluate(self, info, now=None):
        """returns (active_codes, new_violations)"""
        now = now or time.time()
        active = set()

        if info["faces"] == 0:
            active.add("NO_FACE")
        else:
            if info["faces"] > 1 or info["persons"] > 1:
                active.add("MULTIPLE_FACES")
            if self.calibrating and info["faces"] == 1:
                self._calib.append((info["yaw"], info["pitch"]))
                if not self.calibrating:
                    self.base_yaw = float(np.median([c[0] for c in self._calib]))
                    self.base_pitch = float(np.median([c[1] for c in self._calib]))
            elif not self.calibrating:
                dy = info["yaw"] - self.base_yaw
                dp = info["pitch"] - self.base_pitch
                if abs(dy) > YAW_THRESHOLD:
                    active.add("LOOKING_AWAY")
                elif dp > PITCH_DOWN:
                    active.add("LOOKING_DOWN")
                elif dp < -PITCH_UP:
                    active.add("LOOKING_AWAY")

        if info["phone"]:
            active.add("PHONE")
        if info["book"]:
            active.add("BOOK")

        return self._apply(active, now)

    def _apply(self, active, now):
        new = []
        for code in list(self._since):
            if code not in active:
                del self._since[code]
        for code in active:
            self._since.setdefault(code, now)
            if (now - self._since[code] >= RULES[code][0]
                    and now - self._last_fired.get(code, 0) >= COOLDOWN):
                new.append(self.add_violation(code, now=now))
        return sorted(active), new

    def add_violation(self, code, detail="", now=None):
        now = now or time.time()
        if code not in RULES:
            raise ValueError(f"unknown violation: {code}")
        _, weight, msg = RULES[code]
        v = {
            "time": datetime.fromtimestamp(now).strftime("%H:%M:%S"),
            "elapsed_sec": int(now - self.started),
            "code": code,
            "message": msg + (f" ({detail})" if detail else ""),
            "weight": weight,
        }
        self._last_fired[code] = now
        self.violations.append(v)
        self.score += weight
        self.save()
        return v

    def report(self):
        counts = {}
        for v in self.violations:
            counts[v["code"]] = counts.get(v["code"], 0) + 1
        return {
            "session_id": self.sid,
            "candidate": self.name,
            "duration_sec": int(time.time() - self.started),
            "score": self.score,
            "flag_threshold": FLAG_SCORE,
            "flagged_for_review": self.flagged,
            "summary": counts,
            "violations": self.violations,
            "note": "Ye sirf automated signals hain. Final decision human reviewer ka hona chahiye.",
        }

    def save(self):
        try:
            LOG_DIR.mkdir(exist_ok=True)
            (LOG_DIR / f"{self.sid}.json").write_text(json.dumps(self.report(), indent=2))
        except OSError:
            pass


# -------------------------------- OVERLAY -----------------------------------
def build_overlay(info, session, active):
    """Screen par draw hone wale boxes (0-1 normalized) + live warning text."""
    active = set(active)
    boxes = []
    head_bad = "LOOKING_AWAY" in active or "LOOKING_DOWN" in active

    for i, b in enumerate(info["face_boxes"]):
        if i == 0:
            if session.calibrating:
                label, bad = "CALIBRATING - seedha dekho", False
            elif "LOOKING_AWAY" in active:
                label, bad = "LOOKING AWAY", True
            elif "LOOKING_DOWN" in active:
                label, bad = "LOOKING DOWN", True
            else:
                label, bad = "CANDIDATE OK", False
        else:
            label, bad = "EXTRA PERSON", True
        boxes.append({"box": b, "label": label, "bad": bad})

    # YOLO se extra person, jab face-mesh unhe pakad na paaye
    if info["persons"] > 1 and info["faces"] < 2:
        for o in info["objects"]:
            if o["name"] == "person":
                boxes.append({"box": o["box"], "label": "PERSON", "bad": True})

    for o in info["objects"]:
        if o["name"] in ("phone", "book"):
            boxes.append({"box": o["box"], "bad": True,
                          "label": f'{o["name"].upper()} {o["conf"]:.0%}'})

    alerts = [LIVE_TEXT[c] for c in LIVE_TEXT if c in active]
    return {"boxes": boxes, "alerts": alerts, "calibrating": session.calibrating,
            "head_bad": head_bad}
