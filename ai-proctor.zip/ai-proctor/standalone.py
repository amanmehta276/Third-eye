"""
standalone.py - bina browser ke, seedha webcam par test karo.
Run: python standalone.py        (q dabao = quit, report print hoti hai)
"""
import json
import sys
import time

import cv2

from proctor_core import Analyzer, Session, build_overlay

use_yolo = "--no-yolo" not in sys.argv
analyzer = Analyzer(use_yolo=use_yolo)
session = Session("local-test", "Aman")

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    sys.exit("Webcam open nahi hua. Camera index/permission check karo.")

GREEN, RED, WHITE = (0, 200, 0), (0, 0, 230), (255, 255, 255)


def label_box(frame, x1, y1, x2, y2, text, color):
    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 3)
    (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
    ty = y1 - th - 8 if y1 - th - 8 > 0 else y1 + 2
    cv2.rectangle(frame, (x1, ty), (x1 + tw + 8, ty + th + 8), color, -1)
    cv2.putText(frame, text, (x1 + 4, ty + th + 2), cv2.FONT_HERSHEY_SIMPLEX, 0.6, WHITE, 2)


while True:
    ok, frame = cap.read()
    if not ok:
        break
    h, w = frame.shape[:2]

    info = analyzer.analyze(frame)
    active, new = session.evaluate(info)
    ov = build_overlay(info, session, active)

    for b in ov["boxes"]:
        x1, y1, x2, y2 = b["box"]
        label_box(frame, int(x1 * w), int(y1 * h), int(x2 * w), int(y2 * h),
                  b["label"], RED if b["bad"] else GREEN)

    # live red warnings on top
    y = 0
    for text in ov["alerts"]:
        cv2.rectangle(frame, (0, y), (w, y + 34), RED, -1)
        cv2.putText(frame, "CHEATING SUSPECTED: " + text, (10, y + 24),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, WHITE, 2)
        y += 36

    status = "Calibrating... seedha dekho" if ov["calibrating"] else "Monitoring"
    cv2.putText(frame, f"{status} | Score {session.score}/10", (10, h - 12),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, GREEN if not ov["alerts"] else RED, 2)
    if session.flagged:
        cv2.putText(frame, "FLAGGED FOR REVIEW", (w - 260, h - 12),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, RED, 2)

    cv2.imshow("AI Proctor (q = quit)", frame)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
print(json.dumps(session.report(), indent=2))
