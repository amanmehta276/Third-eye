# AI Proctor

Live webcam par cheating detection: face boxes, phone/book detection, looking away/down,
extra person, tab switch, copy-paste, fullscreen exit, background noise.

## Setup
    python -m venv venv
    venv\Scripts\activate        # Mac/Linux: source venv/bin/activate
    pip install -r requirements.txt

## Run (browser version)
    uvicorn main:app --reload
    -> http://localhost:8000

Sirf face/head detection (fast, YOLO ke bina):
    set PROCTOR_YOLO=0           # Mac/Linux: export PROCTOR_YOLO=0

## Run (bina browser, seedha webcam window)
    python standalone.py

## Screen par kya dikhta hai
- Green box = candidate OK, Red box = looking away / looking down / extra person / phone / book
- Video ke upar red "CHEATING SUSPECTED: ..." warning turant aati hai
- Log aur score thoda ruk ke (hold time) update hote hain taaki false positives kam hon

## Tuning (proctor_core.py ke upar)
YAW_THRESHOLD, PITCH_DOWN, PITCH_UP (kam = zyada sensitive), YOLO_CONF, RULES ke hold seconds.

Note: ye automated signals hain. Final decision hamesha human reviewer ka hona chahiye.
